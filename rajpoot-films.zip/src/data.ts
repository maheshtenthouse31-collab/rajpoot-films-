import { PortfolioItem, PricingPackage, Testimonial } from './types';
import pic1 from './assets/images/regenerated_image_1780655491862.jpg';
import pic2 from './assets/images/regenerated_image_1780655493710.jpg';
import pic3 from './assets/images/regenerated_image_1780655495310.jpg';
import pic4 from './assets/images/regenerated_image_1780655496672.jpg';
import pic13 from './assets/images/regenerated_image_1780655270608.jpg';

export const portfolioItems: PortfolioItem[] = [
  {
    id: '1',
    title: 'Nuptial Royalty & Golden Hour',
    category: 'wedding',
    url: pic1,
    fallbackUrl: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Umaid Bhawan Palace, Jodhpur',
    year: '2026'
  },
  {
    id: '2',
    title: 'The Eternal Vows & Red Veil',
    category: 'wedding',
    url: pic2,
    fallbackUrl: 'https://images.unsplash.com/photo-1607190074257-dd4b7af0309f?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'The Leela Palace, Udaipur',
    year: '2025'
  },
  {
    id: '3',
    title: 'Ethereal Forest Romance',
    category: 'pre-wedding',
    url: pic3,
    fallbackUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop',
    aspect: 'landscape',
    location: 'Kashmir Meadows',
    year: '2026'
  },
  {
    id: '4',
    title: 'Lakeside Silhouettes',
    category: 'pre-wedding',
    url: pic4,
    fallbackUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=1200&auto=format&fit=crop',
    aspect: 'wide',
    location: 'Pangong Lake, Ladakh',
    year: '2025'
  },
  {
    id: '5',
    title: 'Vintage Storytelling & Haldi Joy',
    category: 'wedding',
    url: '/WhatsApp Image 2026-06-05 at 3.40.10 PM.jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=1200&auto=format&fit=crop',
    aspect: 'landscape',
    location: 'Fort Barwara, Sawai Madhopur',
    year: '2026'
  },
  {
    id: '6',
    title: 'The Cinematic Flare',
    category: 'cinematic-film',
    url: '/WhatsApp Image 2026-06-05 at 3.40.10 PM (1).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1537633552985-df8429e8048b?q=80&w=1200&auto=format&fit=crop',
    aspect: 'landscape',
    location: 'Marine Drive Nocturne, Mumbai',
    year: '2026'
  },
  {
    id: '7',
    title: 'Gaze into Destiny',
    category: 'fashion-portrait',
    url: '/WhatsApp Image 2026-06-05 at 3.40.10 PM (2).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Rajpoot Luxury Studio, New Delhi',
    year: '2026'
  },
  {
    id: '8',
    title: 'The Royal Grooms Legacy',
    category: 'fashion-portrait',
    url: '/WhatsApp Image 2026-06-05 at 3.40.11 PM.jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Taj Bengal, Kolkata',
    year: '2025'
  },
  {
    id: '9',
    title: 'Warm Sunset Embraces',
    category: 'pre-wedding',
    url: '/WhatsApp Image 2026-06-05 at 3.40.11 PM (1).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop',
    aspect: 'landscape',
    location: 'Amber Fort, Jaipur',
    year: '2026'
  },
  {
    id: '10',
    title: 'Intimate Whispers',
    category: 'pre-wedding',
    url: '/WhatsApp Image 2026-06-05 at 3.40.11 PM (2).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Aravali Hills Vista',
    year: '2026'
  },
  {
    id: '11',
    title: 'The Regal Monochromatic Charm',
    category: 'cinematic-film',
    url: '/WhatsApp Image 2026-06-05 at 3.40.12 PM.jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Classic Legacy Residence',
    year: '2025'
  },
  {
    id: '12',
    title: 'Bride Grand Entry Reveal',
    category: 'wedding',
    url: '/WhatsApp Image 2026-06-05 at 3.40.12 PM (1).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
    aspect: 'landscape',
    location: 'JW Marriott, Jaipur',
    year: '2026'
  },
  {
    id: '13',
    title: 'Framing Love in Motion',
    category: 'cinematic-film',
    url: pic13,
    fallbackUrl: 'https://images.unsplash.com/photo-1478720143022-df85a155c62d?q=80&w=1200&auto=format&fit=crop',
    aspect: 'wide',
    location: 'Film City, Mumbai',
    year: '2026'
  },
  {
    id: '14',
    title: 'Fine-Art Bridal Jewelry Gaze',
    category: 'fashion-portrait',
    url: '/WhatsApp Image 2026-06-05 at 3.40.13 PM.jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Studio Rajpoot, New Delhi',
    year: '2026'
  },
  {
    id: '15',
    title: 'Tale of Two Hearts',
    category: 'wedding',
    url: '/WhatsApp Image 2026-06-05 at 3.40.13 PM (1).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Heritage Grand Palace',
    year: '2026'
  },
  {
    id: '16',
    title: 'Cinematographer Behind the Lens',
    category: 'cinematic-film',
    url: '/WhatsApp Image 2026-06-05 at 3.40.13 PM (2).jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop',
    aspect: 'landscape',
    location: 'Highland Ridge',
    year: '2026'
  },
  {
    id: '17',
    title: 'Gilded Luxury Portraiture',
    category: 'fashion-portrait',
    url: '/WhatsApp Image 2026-06-05 at 3.40.14 PM.jpeg',
    fallbackUrl: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?q=80&w=1200&auto=format&fit=crop',
    aspect: 'portrait',
    location: 'Studio Rajpoot, Mumbai',
    year: '2026'
  }
];

export const pricingPackages: PricingPackage[] = [
  {
    id: 'wedding-gold',
    name: 'Royal Heritage Wedding',
    tagline: 'Capturing the complete narrative of your wedding celebrations with signature grandeur.',
    price: '₹1,45,000',
    priceValue: 145000,
    duration: '2 Full Days',
    category: 'wedding',
    recommended: true,
    crewDetails: '2 Senior Photographers + 2 Cinematographers + Drone Operator',
    features: [
      'Comprehensive Coverage (Candid & Traditional)',
      'Cinematic Wedding Highlight Film (5-7 mins)',
      'Full Traditional Wedding Video (90-120 mins)',
      'Interactive Web Gallery with 350+ Retouched Photos',
      'Exclusive Leather-Bound Royal Photo Album (40 Pages)',
      'Express Delivery within 30 days'
    ]
  },
  {
    id: 'prewed-dream',
    name: 'Aetherial Pre-Wedding',
    tagline: 'A romantic, narrative-driven photoshoot in picturesque destinations.',
    price: '₹65,000',
    priceValue: 65000,
    duration: '1 Full Day',
    category: 'pre-wedding',
    recommended: false,
    crewDetails: '1 Lead Photographer + 1 Cinematographer',
    features: [
      'Up to 3 scenic outdoor locations',
      '4 Outfit changes supported',
      'Cinematic Love Story Teaser Film (3 mins)',
      '120+ Curated and High-End Retouched images',
      'Personal Stylist and Mood Board planning consultation',
      'Digital delivery in 21 days'
    ]
  },
  {
    id: 'cinema-epic',
    name: 'Cinematic Memoir Film',
    tagline: 'Hollywood-grade, cinematic-look storytelling tailored for high-profile portfolios.',
    price: '₹1,10,000',
    priceValue: 110000,
    duration: '12 Full Hours',
    category: 'cinematic-film',
    recommended: false,
    crewDetails: 'Lead Director + 2 Cinematographers + Gimbal Specialist',
    features: [
      '4K HDR RED/ARRI-Vibe Cinematic Grading',
      'Professionally mixed sound design and cinematic score',
      'Custom Script & Storyboarding session',
      'Cinematic Trailer (60 secs) + Director’s Cut (12 mins)',
      'Full visual asset review portal',
      'Delivery with custom Raw Master Footage Drive'
    ]
  },
  {
    id: 'fashion-fine',
    name: 'Avant-Garde Portraiture',
    tagline: 'High-end fine art and editorial bridal modeling portraits.',
    price: '₹40,000',
    priceValue: 40000,
    duration: '4 Hours Studio',
    category: 'fashion-portrait',
    recommended: false,
    crewDetails: '1 Studio Portrait Photographer + Professional Studio Lighting Crew',
    features: [
      'High-fashion studio setup with artistic lighting',
      '3 Curated styling changes',
      '40 Fine-Art Retouched High-Resolution masterpieces',
      'Magazine cover-style expert retouching and design',
      'Digital high-speed cloud distribution folder',
      'Commercial usage release license included'
    ]
  }
];

export const clientTestimonials: Testimonial[] = [
  {
    id: 't1',
    clientName: 'Aarav',
    partnerName: 'Ishita Rajpoot',
    quote: 'Absolutely breathtaking! Rajpoot Films captured our wedding at Udaipur with such cinematic masterpiece style. The video backdrop they created for our entry felt right out of an epic movie. The attention to cultural nuances and detail is pure gold.',
    shootType: 'Royal Wedding Film',
    location: 'Udaipur, Rajasthan',
    rating: 5,
    date: 'February 2026',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop'
  },
  {
    id: 't2',
    clientName: 'Priyanka Sen',
    quote: 'The Avant-Garde studio session exceeded all expectations. They treated every frame like a Renaissance painting. The lighting layout that Rajpoot Films crafted gave my designer jewelry portfolio an incredibly luxurious edge. Will recommend them for all my label work!',
    shootType: 'High-Fashion Bridal Editorial',
    location: 'South Delhi Studio',
    rating: 5,
    date: 'April 2026',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop'
  },
  {
    id: 't3',
    clientName: 'Devansh',
    partnerName: 'Riya Malhotra',
    quote: 'We booked their pre-wedding package in Kashmir, and every single photo evokes immense feelings. Their crew was super warm, guided our poses gracefully, and standard delivery was faster than promised! The teaser video is played on-repeat by both of our families!',
    shootType: 'Pre-Wedding Love Story Film',
    location: 'Gulmarg, Kashmir',
    rating: 5,
    date: 'January 2026',
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=150&auto=format&fit=crop'
  }
];

export const bookingTimeSlots = [
  '09:00 AM - 11:30 AM',
  '12:00 PM - 02:30 PM',
  '03:00 PM - 05:30 PM (Golden Hour Slot)',
  '06:00 PM - 08:30 PM (Twilight Shoot)'
];
