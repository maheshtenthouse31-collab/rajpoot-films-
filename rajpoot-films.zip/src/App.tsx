/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Hero from './components/Hero';
import Gallery from './components/Gallery';
import BookingSystem from './components/BookingSystem';
import Testimonials from './components/Testimonials';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';

export default function App() {
  const triggerBookingScroll = () => {
    const bookingSection = document.getElementById('services-and-pricing');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#070708] font-sans antialiased selection:bg-gold-500 selection:text-black">
      {/* Premium Ambient Lights behind entire webpage body */}
      <div className="fixed top-0 left-0 w-full h-full bg-[#070708] -z-10" />

      {/* Hero Section with Video Banner and Navbar Navigation */}
      <Hero onBookNowClick={triggerBookingScroll} />

      {/* Curated Portfolio Gallery */}
      <Gallery />

      {/* Interactive Reservation System & Pricing Packages */}
      <BookingSystem />

      {/* Endearing Client Testimonials with live feedback custom forms */}
      <Testimonials />

      {/* Contact Forms & Local Studio Coordinate Blocks */}
      <ContactForm />

      {/* Footer Branding Info */}
      <Footer />
    </div>
  );
}
