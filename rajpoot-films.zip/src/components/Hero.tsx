import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Calendar, ChevronDown, Camera, Play, Pause, Menu, X } from 'lucide-react';

interface HeroProps {
  onBookNowClick: () => void;
}

export default function Hero({ onBookNowClick }: HeroProps) {
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(videoRef.current.muted);
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(() => {});
      }
      setIsPlaying(!isPlaying);
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <div id="home" className="relative h-screen w-full overflow-hidden bg-black text-white">
      {/* Background Video */}
      <div className="absolute inset-0 h-full w-full select-none overflow-hidden">
        <video
          ref={videoRef}
          src="/WhatsApp Video 2026-06-05 at 3.38.53 PM.mp4"
          className="h-full w-full object-cover scale-102 filter brightness-85"
          autoPlay
          loop
          muted={isMuted}
          playsInline
        />
        {/* Soft, textured ambient overlays for movie-theater style luxury */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black/45" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,0,0,0)_30%,rgba(0,0,0,0.85)_100%)]" />
      </div>

      {/* Floating Glassmorphic Header */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out ${
          scrolled
            ? 'bg-[#0a0a0c]/85 border-b border-white/5 py-4 backdrop-blur-md shadow-2xl'
            : 'bg-transparent py-6'
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 md:px-12">
          {/* Logo Brand Title */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => scrollToSection('home')}
          >
            <div className="relative flex h-10 w-10 items-center justify-center rounded-full border border-gold-500/30 bg-black/60 backdrop-blur-sm">
              <Camera className="h-5 w-5 text-gold-500" />
              <div className="absolute inset-0 animate-ping rounded-full border border-gold-500/10 opacity-30 pointer-events-none" />
            </div>
            <div className="flex flex-col">
              <span className="font-sans text-xl md:text-2xl font-black tracking-tighter uppercase text-white transition-colors group-hover:text-gold-500">
                Rajpoot Films
              </span>
              <span className="font-mono text-[8px] tracking-[0.2em] uppercase text-gold-500 -mt-0.5 font-bold">
                Cinematic Storytelling
              </span>
            </div>
          </motion.div>

          {/* Nav Targets */}
          <div className="hidden md:flex items-center gap-8 font-sans text-sm tracking-widest uppercase text-gray-300">
            {['gallery', 'services-and-pricing', 'testimonials', 'contact'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item)}
                className="hover:text-gold-500 transition-colors duration-300 cursor-pointer text-xs font-medium"
              >
                {item.replace('-and-pricing', '').toUpperCase()}
              </button>
            ))}
          </div>

          {/* Highlight Call-to-Action & Mobile Trigger */}
          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onBookNowClick}
              className="rounded-full bg-gold-500 px-4 py-2 md:px-6 md:py-2.5 font-sans text-[10px] md:text-xs font-semibold uppercase tracking-widest text-black shadow-[0_0_15px_rgba(242,125,38,0.3)] transition-all duration-300 hover:bg-gold-600 hover:shadow-[0_0_25px_rgba(242,125,38,0.5)] cursor-pointer"
            >
              Book Session
            </motion.button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="flex md:hidden h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-black/40 text-gray-300 hover:text-white transition-colors"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="h-4 w-4 text-gold-500" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed inset-x-0 top-[72px] z-40 md:hidden bg-[#070708]/98 border-b border-white/5 backdrop-blur-2xl py-8 px-6 shadow-2xl flex flex-col gap-6"
          >
            <div className="flex flex-col gap-4">
              {['gallery', 'services-and-pricing', 'testimonials', 'contact'].map((item, index) => (
                <motion.button
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="text-left py-2.5 font-sans text-xs tracking-[0.2em] uppercase font-bold text-gray-300 hover:text-gold-500 border-b border-white/5 transition-colors cursor-pointer"
                >
                  {item.replace('-and-pricing', '').toUpperCase()}
                </motion.button>
              ))}
            </div>
            <div className="text-center pt-2">
              <span className="font-mono text-[8px] tracking-[0.3em] uppercase text-gold-500 font-bold">
                Rajpoot Films Studio
              </span>
              <p className="text-[10px] text-gray-500 mt-1">Cinematic Excellence since 2014 • India</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Hero Elements */}
      <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="max-w-4xl"
        >
          {/* Subtitle Accent */}
          <div className="mb-4">
            <span className="font-sans text-[11px] font-black tracking-[0.4em] uppercase text-gold-500">
              CINEMATIC STORYTELLING & VISUAL ART
            </span>
          </div>

          {/* Hero Headline */}
          <h1 className="font-sans text-5xl sm:text-7xl md:text-[95px] lg:text-[115px] leading-[0.85] font-black uppercase tracking-tighter mb-8 text-white">
            Capturing the <br />
            <span className="text-stroke text-white select-none transition-colors duration-500 hover:text-gold-500">
              Unseen Detail
            </span>
          </h1>

          {/* Beautiful Description Text */}
          <p className="mx-auto mt-6 max-w-2xl font-sans text-sm md:text-md text-gray-300 font-light leading-relaxed tracking-wide mb-10">
            Award-winning luxury wedding cinematography, grand pre-wedding cinematic love stories, 
            and premium fine-art portrait photography. We render your core memories into timeless filmic treasures.
          </p>

          <div className="flex justify-center space-x-12 mt-4 mb-10">
            <div className="text-left">
              <span className="block text-4xl font-black italic text-gold-500">12+</span>
              <span className="text-[10px] uppercase opacity-50 tracking-wider font-semibold">Years of Craft</span>
            </div>
            <div className="text-left border-l border-white/20 pl-12">
              <span className="block text-4xl font-black italic text-gold-500">500+</span>
              <span className="text-[10px] uppercase opacity-50 tracking-wider font-semibold font-sans">Films Delivered</span>
            </div>
          </div>

          {/* Controls & Nav Buttons */}
          <div className="flex flex-wrap justify-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => scrollToSection('gallery')}
              className="rounded-full border border-white/20 bg-white/5 px-8 py-3.5 font-sans text-xs font-semibold uppercase tracking-widest text-white backdrop-blur-md transition-all duration-300 hover:bg-white/10 hover:border-white/40 cursor-pointer"
            >
              Explore Portfolio
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onBookNowClick}
              className="flex items-center gap-2 rounded-full bg-gold-500 px-8 py-3.5 font-sans text-xs font-semibold uppercase tracking-widest text-black shadow-lg transition-all duration-300 hover:bg-gold-600 cursor-pointer"
            >
              <Calendar className="h-4 w-4" /> Secure Your Date
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Floating Bottom Media Bar */}
      <div className="absolute bottom-10 left-6 md:left-12 flex items-center gap-3 z-20">
        {/* Play/Pause Button */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={togglePlay}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-black/40 text-white backdrop-blur-md transition-colors hover:bg-white/15 hover:border-white/40 cursor-pointer"
          title={isPlaying ? "Pause Video" : "Play Video"}
        >
          {isPlaying ? <Pause className="h-4 w-4 text-gold-500" /> : <Play className="h-4 w-4 text-gold-500" />}
        </motion.button>

        {/* Audio Mute/Unmute */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleMute}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-black/40 text-white backdrop-blur-md transition-colors hover:bg-white/15 hover:border-white/40 cursor-pointer"
          title={isMuted ? "Unmute Cinematic Score" : "Mute Video"}
        >
          {isMuted ? (
            <VolumeX className="h-4 w-4 text-gray-400" />
          ) : (
            <Volume2 className="h-4 w-4 text-gold-500 animate-pulse" />
          )}
        </motion.button>

        <span className="font-mono text-[9px] uppercase tracking-widest text-gray-400">
          {isMuted ? "Score Muted" : "Cinematography Sensation Play"}
        </span>
      </div>

      {/* Bounce Down Chevron Arrow */}
      <div className="absolute bottom-8 right-6 md:right-12 z-20 hidden sm:block">
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          onClick={() => scrollToSection('gallery')}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-black/20 text-gray-400 backdrop-blur-sm cursor-pointer hover:border-gold-500/40 hover:text-gold-500 transition-colors"
        >
          <ChevronDown className="h-5 w-5" />
        </motion.div>
      </div>
    </div>
  );
}
