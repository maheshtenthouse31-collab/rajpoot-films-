import { Camera, Instagram, Youtube, Facebook, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#050506] text-white border-t border-white/5 py-12 px-6 md:px-12 relative z-10">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-start border-b border-white/5 pb-12 mb-12">
          
          {/* Column 1: Brand details */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-gold-500/30 bg-black">
                <Camera className="h-4 w-4 text-gold-500" />
              </div>
              <div className="flex flex-col">
                <span className="font-sans text-xl font-black tracking-tighter uppercase text-white">
                  Rajpoot Films
                </span>
                <span className="font-mono text-[8px] tracking-[0.2em] uppercase text-gold-500 -mt-0.5 font-bold">
                  Cinematic Storytelling
                </span>
              </div>
            </div>
            <p className="font-sans text-xs text-gray-500 max-w-sm leading-relaxed font-light">
              Crafting premium visual milestones into timeless narratives. Specializing in high-end luxury weddings, 
              romantic pre-wedding destination sessions, and editorial modeling portfolios since 2018.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h5 className="font-mono text-[10px] tracking-widest uppercase text-gold-500 font-bold">Studio Indexes</h5>
            <ul className="space-y-2 text-xs font-sans text-gray-400 font-light uppercase tracking-wider">
              {['home', 'gallery', 'services-and-pricing', 'testimonials', 'contact'].map((link) => (
                <li key={link}>
                  <button
                    onClick={() => scrollToSection(link)}
                    className="hover:text-gold-500 transition-colors duration-200 cursor-pointer"
                  >
                    {link.replace('-and-pricing', '').replace('home', 'cover')}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Contact Summary */}
          <div className="md:col-span-4 space-y-3">
            <h5 className="font-mono text-[10px] tracking-widest uppercase text-gold-500 font-bold">Contact Coordinates</h5>
            <ul className="space-y-2 text-xs text-gray-400 font-sans font-light">
              <li className="flex items-center gap-2">
                <MapPin className="h-3.5 w-3.5 text-gold-500/80" />
                <span>Gurugram (NCR Delhi) / Udaipur / Mumbai</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-3.5 w-3.5 text-gold-500/80" />
                <a href="tel:+918884949111" className="hover:text-gold-500 transition-colors font-mono">+91 99882 12345</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-3.5 w-3.5 text-gold-500/80" />
                <a href="mailto:booking@rajpootfilms.com" className="hover:text-gold-500 transition-colors">booking@rajpootfilms.com</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Closing, social icons, and copyright details */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-500 font-light">
          <div>
            <span className="font-mono text-[10px] tracking-widest text-gold-500/70 block uppercase font-medium">Rajpoot Films Studio • Delhi NCR | Jaipur | Mumbai</span>
            <p className="mt-1 font-sans">
              © {currentYear} Rajpoot Films. All visual assets and cinematography rights reserved.
            </p>
          </div>

          {/* Social icons */}
          <div className="flex items-center gap-4 text-gray-400">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-gold-500 transition-colors" title="Instagram">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="hover:text-gold-500 transition-colors" title="YouTube">
              <Youtube className="h-4 w-4" />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:text-gold-500 transition-colors" title="Facebook">
              <Facebook className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
