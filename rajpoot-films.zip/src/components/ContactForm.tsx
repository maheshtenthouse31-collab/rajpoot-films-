import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Send, CheckCircle, Camera, Award } from 'lucide-react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'Wedding Cinematography Coverage',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate luxury API communication
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: 'Wedding Cinematography Coverage',
        message: ''
      });
      // Clear success banner later
      setTimeout(() => {
        setSubmitted(false);
      }, 5000);
    }, 1500);
  };

  return (
    <section id="contact" className="relative bg-[#0c0c0e] py-24 md:py-32 px-6 md:px-12 text-white overflow-hidden">
      {/* Visual background flares */}
      <div className="absolute top-1/2 right-1/4 h-80 w-80 rounded-full bg-gold-600/5 blur-[120px] pointer-events-none animate-pulse" />

      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* LEFT COLUMN: Brand Statement & Touchpoints */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="h-[2px] w-8 bg-gold-500" />
                <span className="font-mono text-xs uppercase tracking-widest text-gold-500 font-semibold">
                  GET IN TOUCH
                </span>
              </div>
              <h2 className="font-sans text-4xl sm:text-6xl md:text-7xl font-black uppercase tracking-tighter text-white mb-6">
                Start a <span className="text-stroke text-white select-none transition-colors duration-300 hover:text-gold-500">Conversation</span>
              </h2>
              <p className="font-sans text-sm md:text-md text-gray-400 font-light leading-relaxed">
                Whether you’re planning a destination royal wedding, an editorial fashion campaign, 
                or a passion independent film project, Rajpoot Films is eager to explore your creative horizon. Let’s compose visual magic together.
              </p>
            </div>

            {/* Structured Info Cards */}
            <div className="space-y-4">
              {/* Phone Node */}
              <div className="flex items-center gap-4 p-4 rounded-xl border border-white/5 bg-[#0f0f12]">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold-500/10 text-gold-500">
                  <Phone className="h-4 w-4" />
                </div>
                <div>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-gray-500">Direct Hotline</span>
                  <a href="tel:+918884949111" className="block text-sm font-semibold text-white hover:text-gold-500 font-mono transition-colors">
                    +91 99882 12345
                  </a>
                </div>
              </div>

              {/* Email Node */}
              <div className="flex items-center gap-4 p-4 rounded-xl border border-white/5 bg-[#0f0f12]">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold-500/10 text-gold-500">
                  <Mail className="h-4 w-4" />
                </div>
                <div>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-gray-500">Official Correspondence</span>
                  <a href="mailto:booking@rajpootfilms.com" className="block text-sm font-semibold text-white hover:text-gold-500 font-sans transition-colors">
                    booking@rajpootfilms.com
                  </a>
                </div>
              </div>

              {/* Studio Locations Node */}
              <div className="flex items-start gap-4 p-4 rounded-xl border border-white/5 bg-[#0f0f12]">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold-500/10 text-gold-500 mt-1">
                  <MapPin className="h-4 w-4" />
                </div>
                <div>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-gray-500">Studio Coordinates</span>
                  <span className="block text-xs font-light text-gray-300 leading-relaxed font-sans mt-0.5">
                    <strong>Studio Rajpoot Films:</strong> DLF Phase 1, Gurugram, NCR Delhi / Royal Vista Palace Tower, Jodhpur / Film City Phase 2, Goregaon East, Mumbai.
                  </span>
                </div>
              </div>
            </div>

            {/* Quick credentials / brand trust markers */}
            <div className="pt-6 border-t border-white/5 flex gap-4 text-xs font-mono text-gray-500 tracking-widest uppercase">
              <span className="flex items-center gap-1">
                <Camera className="h-3.5 w-3.5 text-gold-500" /> RAW ARCHIVAL
              </span>
              <span className="flex items-center gap-1">
                <Award className="h-3.5 w-3.5 text-gold-500" /> MULTY-AWARD CREW
              </span>
            </div>
          </div>

          {/* RIGHT COLUMN: Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-[#0f0f12] rounded-xl border border-white/5 p-6 md:p-8 shadow-2xl relative">
              
              <AnimatePresence>
                {submitted && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    className="absolute inset-0 bg-[#0c0c0e]/98 z-30 flex flex-col items-center justify-center text-center p-6 backdrop-blur-md"
                  >
                    <div className="h-14 w-14 rounded-full bg-gold-500/15 border border-gold-500/40 flex items-center justify-center mb-4 text-gold-500">
                      <CheckCircle className="h-7 w-7 animate-pulse" />
                    </div>
                    <h3 className="font-serif text-2xl font-bold text-white mb-2">Message Dispatched</h3>
                    <p className="text-xs text-gray-400 font-sans max-w-sm leading-relaxed">
                      Your query has entered our pipeline. A senior script executive or portfolio director was assigned and will write back to you within 12 business hours.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>

              <form onSubmit={handleFormSubmit} className="space-y-5">
                <h4 className="font-serif text-lg md:text-xl font-bold tracking-wide border-b border-white/5 pb-4 mb-4">
                  Inquire For Custom Pricing Structure
                </h4>

                {/* Client Name */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Your Full Name *</label>
                  <input
                    required
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Ramesh Aggarwal"
                    className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3.5 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white"
                  />
                </div>

                {/* Email and Phone side by side */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Email Address *</label>
                    <input
                      required
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="ramesh@gmail.com"
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3.5 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Phone Number *</label>
                    <input
                      required
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+91 98845 XXXXX"
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3.5 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-mono text-white"
                    />
                  </div>
                </div>

                {/* Subject Selection */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Inquiry Subject *</label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3.5 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white appearance-none cursor-pointer"
                  >
                    <option value="Wedding Cinematography Coverage" className="bg-[#0f0f12]">Wedding Cinematography Coverage</option>
                    <option value="Destination Pre-Wedding Film" className="bg-[#0f0f12]">Destination Pre-Wedding Film</option>
                    <option value="Avant-Garde Studio Portrait Session" className="bg-[#0f0f12]">Avant-Garde Studio Portrait Session</option>
                    <option value="Commercial / Label Shoot Collaboration" className="bg-[#0f0f12]">Commercial / Label Shoot Collaboration</option>
                    <option value="Other Custom Creative Request" className="bg-[#0f0f12]">Other Custom Creative Request</option>
                  </select>
                </div>

                {/* Message block */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Your Message & Creative Narrative *</label>
                  <textarea
                    required
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Tell us about your event timelines, expected deliverables, crew size preference, theme setup..."
                    className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3.5 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white"
                  />
                </div>

                {/* Submit action */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-lg bg-gold-500 hover:bg-gold-600 font-sans text-xs font-bold uppercase tracking-widest text-black flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="h-4 w-4 border-2 border-black border-t-transparent rounded-full"
                    />
                  ) : (
                    <>
                      <Send className="h-3.5 w-3.5" /> Dispatch Inquiry
                    </>
                  )}
                </motion.button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
