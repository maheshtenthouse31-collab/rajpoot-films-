import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { clientTestimonials } from '../data';
import { Testimonial } from '../types';
import { Star, MessageSquare, Plus, Check } from 'lucide-react';

export default function Testimonials() {
  const [list, setList] = useState<Testimonial[]>(clientTestimonials);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [shootType, setShootType] = useState('Royal Wedding Film');
  const [location, setLocation] = useState('');
  const [quote, setQuote] = useState('');
  const [rating, setRating] = useState(5);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('rajpoot_films_testimonials');
      if (stored) {
        const parsed = JSON.parse(stored);
        setList([...clientTestimonials, ...parsed]);
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !quote) return;

    const newTestimonial: Testimonial = {
      id: `custom-${Date.now()}`,
      clientName: name,
      quote,
      shootType,
      location: location || 'Studio Location',
      rating,
      date: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      avatarUrl: `https://images.unsplash.com/photo-${Math.floor(1500000000000 + Math.random() * 100000000000)}?q=80&w=150&auto=format&fit=crop`
    };

    const localItems = JSON.parse(localStorage.getItem('rajpoot_films_testimonials') || '[]');
    const updatedLocal = [...localItems, newTestimonial];
    localStorage.setItem('rajpoot_films_testimonials', JSON.stringify(updatedLocal));

    setList([...clientTestimonials, ...updatedLocal]);
    setSuccess(true);

    // reset fields
    setName('');
    setLocation('');
    setQuote('');
    setRating(5);

    setTimeout(() => {
      setSuccess(false);
      setShowForm(false);
    }, 2500);
  };

  return (
    <section id="testimonials" className="relative bg-[#070708] py-24 md:py-32 px-6 md:px-12 text-white overflow-hidden">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gold-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="mx-auto max-w-7xl">
        
        {/* Editorial Heading Grid */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 md:mb-24">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="h-[2px] w-8 bg-gold-500" />
              <span className="font-mono text-xs uppercase tracking-widest text-gold-500 font-semibold">
                CLIENT VENERATION
              </span>
            </div>
            <h2 className="font-sans text-4xl sm:text-6xl md:text-7xl font-black uppercase tracking-tighter text-white">
              Endearing <span className="text-stroke text-white select-none transition-colors duration-300 hover:text-gold-500">Feedback</span>
            </h2>
            <p className="mt-4 font-sans text-sm md:text-md text-gray-400 font-light leading-relaxed">
              We describe luxury through the speech of our lovely clients. Here are their genuine reactions to witnessing their memories immortalized in motion.
            </p>
          </div>

          <div className="mt-6 md:mt-0 flex gap-4 shrink-0">
            <button
              onClick={() => setShowForm(!showForm)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full border border-gold-500/25 bg-gold-937213/5 text-xs font-semibold tracking-widest uppercase text-gold-500 hover:bg-gold-500 hover:text-black transition-all duration-300 cursor-pointer"
            >
              <Plus className="h-4 w-4" /> Share Your Experience
            </button>
          </div>
        </div>

        {/* Dynamic Testimonial Write Module Overlay */}
        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden mb-12"
            >
              <div className="bg-[#0f0f12] border border-white/5 rounded-xl p-6 md:p-8 max-w-2xl mx-auto shadow-2xl relative">
                
                {success && (
                  <div className="absolute inset-0 bg-[#0f0f12] z-20 flex flex-col items-center justify-center text-center p-6">
                    <div className="h-12 w-12 rounded-full bg-gold-500/10 border border-gold-500/30 flex items-center justify-center mb-4">
                      <Check className="h-6 w-6 text-gold-500 animate-pulse" />
                    </div>
                    <h4 className="font-serif font-bold text-lg text-white">Feedback Published!</h4>
                    <p className="text-xs text-gray-400 mt-1 font-light">Thank you for sharing your experience with Rajpoot Films.</p>
                  </div>
                )}

                <h3 className="font-serif text-xl font-bold mb-6 text-gold-100 flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-gold-500" /> Pen Your Experience
                </h3>

                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1">Your Name *</label>
                      <input
                        required
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Meera Sharma"
                        className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all text-white font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1">Your Venue / Location</label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="e.g. Udaipur, Rajasthan"
                        className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all text-white font-sans"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1">Session Style</label>
                      <select
                        value={shootType}
                        onChange={(e) => setShootType(e.target.value)}
                        className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all text-gray-300 font-sans"
                      >
                        <option value="Royal Wedding Film">Royal Wedding Film</option>
                        <option value="Pre-Wedding Love Story Film">Pre-Wedding Love Story Film</option>
                        <option value="Cinematic Memoir Film">Cinematic Memoir Film</option>
                        <option value="High-Fashion Bridal Editorial">High-Fashion Bridal Editorial</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-2">Assigned stars ({rating} Stars)</label>
                      <div className="flex items-center gap-2 mt-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            type="button"
                            key={star}
                            onClick={() => setRating(star)}
                            className="text-gray-600 hover:text-gold-500 transition-colors cursor-pointer"
                          >
                            <Star className={`h-6 w-6 ${rating >= star ? 'fill-gold-500 text-gold-500' : 'text-gray-600'}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1">Your Experience Story *</label>
                    <textarea
                      required
                      rows={3}
                      value={quote}
                      onChange={(e) => setQuote(e.target.value)}
                      placeholder="Tell us about your production experience, comfort, styling direction, and resulting films..."
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all text-white font-sans"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-lg bg-gold-500 text-black font-sans text-xs font-semibold uppercase tracking-widest transition-all hover:bg-gold-600 cursor-pointer"
                  >
                    Submit Testimonial
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Staggered testmonials list */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {list.map((item, idx) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              key={item.id}
              className="bg-[#0f0f12] border border-white/5 rounded-2xl p-8 relative flex flex-col justify-between hover:border-gold-500/20 hover:bg-[#111114] transition-all duration-300 shadow-xl group"
            >
              <div>
                {/* Visual quote accent mark */}
                <span className="font-serif text-6xl text-gold-500/10 absolute top-5 left-6 select-none font-bold">“</span>

                {/* Stars feedback */}
                <div className="flex items-center gap-1.5 mb-6 relative z-10">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < item.rating ? 'fill-gold-500 text-gold-500' : 'text-gray-700'
                      }`}
                    />
                  ))}
                </div>

                <p className="font-sans text-sm text-gray-300 font-light leading-relaxed italic relative z-10 mb-8 select-none">
                  "{item.quote}"
                </p>
              </div>

              {/* Client Profile Footer */}
              <div className="flex items-center gap-4 pt-6 border-t border-white/5">
                <div className="h-12 w-12 rounded-full overflow-hidden border border-white/10 shrink-0 bg-neutral-800">
                  <img
                    src={item.avatarUrl}
                    alt={item.clientName}
                    className="h-full w-full object-cover grayscale transition-all duration-300 group-hover:grayscale-0"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="font-serif text-md font-bold text-gold-100">
                    {item.clientName}
                    {item.partnerName && (
                      <span className="text-gray-400 font-sans font-light text-xs block -mt-0.5">
                        & {item.partnerName}
                      </span>
                    )}
                  </h4>
                  <div className="flex flex-col mt-1 font-mono text-[9px] text-gray-500 uppercase tracking-widest">
                    <span className="text-gold-500/80 font-medium">{item.shootType}</span>
                    <span className="font-sans font-light text-gray-500 tracking-normal mt-0.5">{item.location} • {item.date}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
