import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { portfolioItems } from '../data';
import { ShootingCategory, PortfolioItem } from '../types';
import { Search, MapPin, Calendar, X, ChevronLeft, ChevronRight, LayoutGrid } from 'lucide-react';

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState<ShootingCategory>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Filters the items based on category
  const filteredItems = selectedCategory === 'all'
    ? portfolioItems
    : portfolioItems.filter(item => item.category === selectedCategory);

  const categories: { key: ShootingCategory; name: string }[] = [
    { key: 'all', name: 'ALL WORKS' },
    { key: 'wedding', name: 'WEDDINGS' },
    { key: 'pre-wedding', name: 'PRE-WEDDINGS' },
    { key: 'cinematic-film', name: 'CINEMATIC FILMS' },
    { key: 'fashion-portrait', name: 'FINE-ART PORTRAIT' }
  ];

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex + 1) % filteredItems.length);
    }
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex - 1 + filteredItems.length) % filteredItems.length);
    }
  };

  // Safe fallback utility for images not found
  const handleImgLoadError = (e: React.SyntheticEvent<HTMLImageElement>, item: PortfolioItem) => {
    const target = e.currentTarget;
    if (target.src !== item.fallbackUrl) {
      target.src = item.fallbackUrl;
    }
  };

  return (
    <section id="gallery" className="relative bg-[#070708] py-24 md:py-32 px-6 md:px-12 text-white">
      {/* Decorative vertical lines and accents */}
      <div className="absolute top-0 left-12 w-[1px] h-full bg-white/5 pointer-events-none hidden md:block" />
      <div className="absolute top-0 right-12 w-[1px] h-full bg-white/5 pointer-events-none hidden md:block" />

      <div className="mx-auto max-w-7xl">
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 md:mb-24">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="h-[2px] w-8 bg-gold-500" />
              <span className="font-mono text-xs uppercase tracking-widest text-gold-500 font-semibold">
                CURATED MASTERPIECES
              </span>
            </div>
            <h2 className="font-sans text-4xl sm:text-6xl md:text-7xl font-black uppercase tracking-tighter text-white">
              Visual <span className="text-stroke text-white select-none transition-colors duration-300 hover:text-gold-500">Poetry</span>
            </h2>
            <p className="mt-4 font-sans text-sm md:text-md text-gray-400 font-light leading-relaxed">
              Every shot is an emotional brushstroke. Traverse our curated anthology from grand royalty-styled legacy weddings to moody avant-garde portraits.
            </p>
          </div>

          {/* Quick stats on layout */}
          <div className="mt-6 md:mt-0 font-mono text-[10px] tracking-widest text-gold-500 border border-gold-500/10 bg-gold-937213/5 rounded-lg px-4 py-2 flex items-center gap-2 self-start md:self-auto">
            <LayoutGrid className="h-3.5 w-3.5" />
            <span>17 STORIES ONLINE</span>
          </div>
        </div>

        {/* Categories Tab Selector */}
        <div className="flex flex-wrap items-center gap-2 md:gap-4 border-b border-white/5 pb-6 mb-12 overflow-x-auto no-scrollbar md:justify-center">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`relative px-4 py-2.5 font-sans text-[11px] md:text-xs font-semibold tracking-widest uppercase transition-all duration-300 cursor-pointer whitespace-nowrap ${
                selectedCategory === cat.key
                  ? 'text-gold-500'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {cat.name}
              {selectedCategory === cat.key && (
                <motion.div
                  layoutId="activeCategoryBorder"
                  className="absolute bottom-0 left-0 right-0 h-[2px] bg-gold-500"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Gallery Masonry-like Bento Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, idx) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.92 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                key={item.id}
                onClick={() => setLightboxIndex(idx)}
                className={`group relative overflow-hidden rounded-xl bg-neutral-900 border border-white/5 cursor-pointer shadow-lg ${
                  item.aspect === 'wide' ? 'sm:col-span-2' : ''
                }`}
              >
                {/* Image Container */}
                <div className="relative aspect-[4/3] w-full overflow-hidden sm:aspect-auto sm:h-80 md:h-[400px]">
                  <img
                    src={item.url}
                    alt={item.title}
                    onError={(e) => handleImgLoadError(e, item)}
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-108 group-hover:filter group-hover:brightness-95 animate-subtle-gaze"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-60 transition-opacity duration-500 group-hover:opacity-80" />
                </div>

                {/* Overlaid Info Detail */}
                <div className="absolute inset-x-0 bottom-0 flex flex-col justify-end p-6 translate-y-2 transition-all duration-500 ease-out group-hover:translate-y-0 text-white">
                  <div className="flex items-center gap-1.5 mb-2 font-mono text-[9px] uppercase tracking-widest text-gold-500">
                    <span className="h-1.5 w-1.5 rounded-full bg-gold-500" />
                    {item.category.replace('-', ' ')}
                  </div>
                  
                  <h3 className="font-serif text-lg md:text-xl font-bold tracking-wide leading-tight mb-2 group-hover:text-gold-100 transition-colors">
                    {item.title}
                  </h3>

                  <div className="flex flex-wrap items-center gap-4 text-gray-400 font-sans text-xs pt-2 border-t border-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    {item.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-gold-500/80" />
                        {item.location}
                      </span>
                    )}
                    {item.year && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-gold-500/80" />
                        {item.year}
                      </span>
                    )}
                  </div>
                </div>

                {/* Aesthetic Hover Lens Visual Border */}
                <div className="absolute inset-3 border border-gold-500/0 pointer-events-none transition-all duration-500 group-hover:border-gold-500/20 rounded-lg" />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Fullscreen Lightbox Portal */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightboxIndex(null)}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/98 px-6 backdrop-blur-md"
          >
            {/* Close Button top-right */}
            <button
              onClick={() => setLightboxIndex(null)}
              className="absolute top-6 right-6 flex h-11 w-11 items-center justify-center rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            {/* Left navigation bullet */}
            <button
              onClick={handlePrev}
              className="absolute left-4 md:left-8 flex h-12 w-12 items-center justify-center rounded-full bg-white/5 border border-white/10 hover:bg-white/15 text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>

            {/* Main Interactive Expanded View */}
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-5xl w-full flex flex-col items-center"
            >
              <div className="relative max-h-[70vh] bg-neutral-950 rounded-xl overflow-hidden shadow-2xl border border-white/5">
                <img
                  src={filteredItems[lightboxIndex].url}
                  alt={filteredItems[lightboxIndex].title}
                  onError={(e) => handleImgLoadError(e, filteredItems[lightboxIndex])}
                  className="max-h-[70vh] w-auto max-w-full object-contain mx-auto"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Lightbox Information Bar */}
              <div className="mt-6 text-center text-white max-w-xl">
                <span className="font-mono text-[10px] tracking-widest text-gold-500 uppercase font-bold block mb-1">
                  {filteredItems[lightboxIndex].category.replace('-', ' ')}
                </span>
                <h4 className="font-serif text-xl sm:text-2xl font-semibold mb-2">
                  {filteredItems[lightboxIndex].title}
                </h4>
                <div className="flex items-center justify-center gap-4 text-xs text-gray-400 font-sans font-light">
                  {filteredItems[lightboxIndex].location && (
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-gold-500" />
                      {filteredItems[lightboxIndex].location}
                    </span>
                  )}
                  {filteredItems[lightboxIndex].year && (
                    <span className="flex items-center gap-1.5">
                      <Calendar className="h-3.5 w-3.5 text-gold-500" />
                      {filteredItems[lightboxIndex].year}
                    </span>
                  )}
                </div>
              </div>
            </motion.div>

            {/* Right navigation bullet */}
            <button
              onClick={handleNext}
              className="absolute right-4 md:right-8 flex h-12 w-12 items-center justify-center rounded-full bg-white/5 border border-white/10 hover:bg-white/15 text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <ChevronRight className="h-6 w-6" />
            </button>

            {/* Index Counter Indicator */}
            <div className="absolute bottom-6 font-mono text-[11px] tracking-widest text-gray-500">
              {lightboxIndex + 1} / {filteredItems.length}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
