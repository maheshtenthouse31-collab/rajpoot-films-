import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { pricingPackages, bookingTimeSlots } from '../data';
import { BookingFormInput, PricingPackage } from '../types';
import { CalendarRange, Clock, Sparkles, User, Mail, Phone, MapPin, Notebook, Check, Trash2, Award } from 'lucide-react';

interface BookingSystemProps {
  // Option to trigger scroll or activation externally
}

interface SavedBooking extends BookingFormInput {
  id: string;
  packageName: string;
  price: string;
  referenceCode: string;
  createdOn: string;
}

export default function BookingSystem({}: BookingSystemProps) {
  const [selectedPkg, setSelectedPkg] = useState<PricingPackage>(pricingPackages[0]);
  const [formInput, setFormInput] = useState<Omit<BookingFormInput, 'packageId'>>({
    name: '',
    email: '',
    phone: '',
    date: '',
    timeSlot: bookingTimeSlots[0],
    location: '',
    details: ''
  });

  const [bookingConfirmed, setBookingConfirmed] = useState<SavedBooking | null>(null);
  const [localBookings, setLocalBookings] = useState<SavedBooking[]>([]);

  // Load bookings from Local Storage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('rajpoot_films_bookings');
      if (stored) {
        setLocalBookings(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Local storage lookup failed", e);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormInput(prev => ({ ...prev, [name]: value }));
  };

  const handlePackageSelect = (pkg: PricingPackage) => {
    setSelectedPkg(pkg);
  };

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Generate custom confirmation receipt ID
    const refCode = `RF-${selectedPkg.category.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    
    const newBooking: SavedBooking = {
      ...formInput,
      packageId: selectedPkg.id,
      packageName: selectedPkg.name,
      price: selectedPkg.price,
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      referenceCode: refCode,
      createdOn: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      })
    };

    const updatedBookings = [newBooking, ...localBookings];
    setLocalBookings(updatedBookings);
    localStorage.setItem('rajpoot_films_bookings', JSON.stringify(updatedBookings));

    setBookingConfirmed(newBooking);

    // Reset fields
    setFormInput({
      name: '',
      email: '',
      phone: '',
      date: '',
      timeSlot: bookingTimeSlots[0],
      location: '',
      details: ''
    });
  };

  const deleteBooking = (id: string) => {
    const filtered = localBookings.filter(b => b.id !== id);
    setLocalBookings(filtered);
    localStorage.setItem('rajpoot_films_bookings', JSON.stringify(filtered));
  };

  // Get current date formatted for min input attribute (can't select past dates)
  const todayDateStr = new Date().toISOString().split('T')[0];

  return (
    <section id="services-and-pricing" className="relative bg-[#0c0c0e] py-24 md:py-32 px-6 md:px-12 text-white">
      {/* Visual background lights */}
      <div className="absolute top-1/4 left-1/3 h-96 w-96 rounded-full bg-gold-600/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-yellow-500/5 blur-[150px] pointer-events-none" />

      <div className="mx-auto max-w-7xl">
        
        {/* Title Frame */}
        <div className="text-center max-w-3xl mx-auto mb-16 md:mb-24">
          <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 border border-gold-500/10 bg-gold-500/5 rounded-full">
            <Sparkles className="h-3 w-3 text-gold-500" />
            <span className="font-mono text-[9px] uppercase tracking-widest text-gold-500 font-semibold">
              PREMIUM PACKAGES & BOOKING ENGINE
            </span>
          </div>
          <h2 className="font-sans text-4xl sm:text-6xl md:text-7xl font-black uppercase tracking-tighter text-white mb-6">
            Signature <span className="text-stroke text-white select-none transition-colors duration-300 hover:text-gold-500">Sessions</span>
          </h2>
          <p className="font-sans text-sm md:text-md text-gray-400 font-light leading-relaxed">
            Select a tailored session package and reserve your production date securely. 
            All reservations include continuous luxury consultation and full RAW asset mastery option.
          </p>
        </div>

        {/* Outer Split: Packages left, interactive reservation system right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* LEFT: Packages List */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="font-sans text-lg md:text-xl font-bold uppercase tracking-tight mb-6 flex items-center gap-2">
              <span className="h-[2px] w-4 bg-gold-500" /> Choose Your Shoot Style
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-6">
              {pricingPackages.map((pkg) => (
                <motion.div
                  key={pkg.id}
                  whileHover={{ scale: 1.01 }}
                  onClick={() => handlePackageSelect(pkg)}
                  className={`group relative p-6 rounded-xl border transition-all duration-500 cursor-pointer ${
                    selectedPkg.id === pkg.id
                      ? 'bg-[#141418] border-gold-500 shadow-[0_0_25px_rgba(212,175,55,0.08)]'
                      : 'bg-[#0f0f12] border-white/5 hover:border-white/10 hover:bg-[#111114]'
                  }`}
                >
                  {pkg.recommended && (
                    <div className="absolute top-4 right-4 bg-gold-500 text-black font-mono text-[8px] font-bold tracking-widest px-2.5 py-1 rounded-full flex items-center gap-1">
                      <Award className="h-3 w-3" /> BESTVALUE
                    </div>
                  )}

                  <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                    <div>
                      <span className="font-mono text-[9px] tracking-widest uppercase text-gold-500/80 font-bold">
                        {pkg.duration} LIMIT • {pkg.category.replace('-', ' ').toUpperCase()}
                      </span>
                      <h4 className="font-serif text-xl font-bold tracking-wide text-gold-100 group-hover:text-gold-500 transition-colors mt-1">
                        {pkg.name}
                      </h4>
                      <p className="text-xs text-gray-400 font-sans mt-2 max-w-md font-light leading-relaxed">
                        {pkg.tagline}
                      </p>
                    </div>

                    <div className="text-left md:text-right shrink-0">
                      <div className="font-serif text-2xl md:text-3xl font-black text-white">
                        {pkg.price}
                      </div>
                      <span className="font-mono text-[10px] text-gray-500 uppercase tracking-wider block">
                        All-Inclusive Charge
                      </span>
                    </div>
                  </div>

                  {/* Included features tags display inside selected package */}
                  <div className={`mt-6 pt-6 border-t border-white/5 space-y-3 transition-all duration-500 ${
                    selectedPkg.id === pkg.id ? 'opacity-100 max-h-screen' : 'opacity-40 max-h-0 overflow-hidden'
                  }`}>
                    <div className="font-mono text-[10px] tracking-wider text-gray-400 uppercase font-medium">
                      CREW LIST: <span className="text-gold-100 font-sans">{pkg.crewDetails}</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-300 font-sans font-light">
                      {pkg.features.map((feat, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <Check className="h-3.5 w-3.5 text-gold-500 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* RIGHT: Booking Engine Form container */}
          <div className="lg:col-span-5">
            <h3 className="font-sans text-lg md:text-xl font-bold uppercase tracking-tight mb-6 flex items-center gap-2">
              <span className="h-[2px] w-4 bg-gold-500" /> Live Reservation
            </h3>

            <div className="bg-[#0f0f12] rounded-xl border border-white/5 p-6 md:p-8 relative shadow-2xl overflow-hidden">
              
              {/* Dynamic confirmation overlay */}
              <AnimatePresence>
                {bookingConfirmed && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="absolute inset-0 bg-[#0c0c0e] z-30 p-6 md:p-8 flex flex-col justify-between"
                  >
                    <div className="text-center my-auto space-y-4">
                      {/* Success Ring Badge */}
                      <div className="mx-auto h-16 w-16 rounded-full bg-gold-500/15 border border-gold-500/30 flex items-center justify-center mb-6">
                        <Check className="h-8 w-8 text-gold-500 animate-bounce" />
                      </div>
                      <h4 className="font-serif text-2xl font-bold text-gold-100">
                        Reservation Secured
                      </h4>
                      <p className="text-xs text-gray-400 font-sans max-w-sm mx-auto font-light leading-relaxed">
                        Your session request has been transmitted. Our production manager will contact you on your registered mobile number shortly.
                      </p>

                      {/* Reciept Core Elements */}
                      <div className="bg-[#141418] border border-white/5 rounded-xl p-5 text-left space-y-3.5 mt-6 max-w-sm mx-auto">
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                          <span className="font-mono text-[9px] text-gray-500 tracking-widest uppercase">CONFIRMATION REF</span>
                          <span className="font-mono text-sm text-gold-500 font-bold">{bookingConfirmed.referenceCode}</span>
                        </div>
                        <div className="text-xs space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Client Name:</span>
                            <span className="font-medium text-white">{bookingConfirmed.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Selected Package:</span>
                            <span className="font-medium text-gold-100">{bookingConfirmed.packageName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Assigned Date:</span>
                            <span className="font-mono font-medium text-white">{bookingConfirmed.date}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Assigned Time:</span>
                            <span className="font-mono font-medium text-white">{bookingConfirmed.timeSlot.split(' (')[0]}</span>
                          </div>
                          <div className="flex justify-between border-t border-white/5 pt-2 font-semibold">
                            <span className="text-gold-500">Estimated Price:</span>
                            <span className="text-white text-sm">{bookingConfirmed.price}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 flex gap-3">
                      <button
                        onClick={() => setBookingConfirmed(null)}
                        className="w-full py-3 bg-white/5 hover:bg-white/10 text-xs font-semibold tracking-widest uppercase rounded-lg border border-white/10 transition-colors cursor-pointer"
                      >
                        New Reservation
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Booking Input Fields */}
              <form onSubmit={handleBookSubmit} className="space-y-4">
                <div className="border-b border-white/5 pb-4 mb-4">
                  <span className="font-mono text-[9px] text-gold-500/80 uppercase tracking-widest font-bold">Selected Package Info</span>
                  <div className="flex justify-between items-center mt-1">
                    <span className="font-serif font-bold text-white text-lg">{selectedPkg.name}</span>
                    <span className="font-serif font-bold text-gold-500 text-lg">{selectedPkg.price}</span>
                  </div>
                </div>

                {/* Client Name */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Your Name *</label>
                  <div className="relative">
                    <input
                      required
                      type="text"
                      name="name"
                      value={formInput.name}
                      onChange={handleInputChange}
                      placeholder="e.g. Ramesh Kumar"
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white pl-10"
                    />
                    <User className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500" />
                  </div>
                </div>

                {/* Grid of Contact: Email & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Email Address *</label>
                    <div className="relative">
                      <input
                        required
                        type="email"
                        name="email"
                        value={formInput.email}
                        onChange={handleInputChange}
                        placeholder="yourname@gmail.com"
                        className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white pl-10"
                      />
                      <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Phone Number *</label>
                    <div className="relative">
                      <input
                        required
                        type="tel"
                        name="phone"
                        value={formInput.phone}
                        onChange={handleInputChange}
                        placeholder="+91 XXXXX XXXXX"
                        className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-mono text-white pl-10"
                      />
                      <Phone className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500" />
                    </div>
                  </div>
                </div>

                {/* Date Selection */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Shoot Date *</label>
                  <div className="relative">
                    <input
                      required
                      type="date"
                      name="date"
                      min={todayDateStr}
                      value={formInput.date}
                      onChange={handleInputChange}
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-mono text-white pl-10 filter invert-0"
                    />
                    <CalendarRange className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500 pointer-events-none" />
                  </div>
                </div>

                {/* Time Slot Selection */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Optimal Time Slot *</label>
                  <div className="relative">
                    <select
                      name="timeSlot"
                      value={formInput.timeSlot}
                      onChange={handleInputChange}
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white pl-10 appearance-none cursor-pointer"
                    >
                      {bookingTimeSlots.map((slot) => (
                        <option key={slot} value={slot} className="bg-[#0f0f12]">
                          {slot}
                        </option>
                      ))}
                    </select>
                    <Clock className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500 pointer-events-none" />
                  </div>
                </div>

                {/* Shoot Venue / Location */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Shoot Venue / Location *</label>
                  <div className="relative">
                    <input
                      required
                      type="text"
                      name="location"
                      value={formInput.location}
                      onChange={handleInputChange}
                      placeholder="e.g. Udaipur, Rajasthan or Studio"
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white pl-10"
                    />
                    <MapPin className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500" />
                  </div>
                </div>

                {/* Custom Details Paragraph */}
                <div>
                  <label className="block text-xs font-mono tracking-widest uppercase text-gray-400 mb-1.5 font-medium">Special Creative Directives</label>
                  <div className="relative">
                    <textarea
                      name="details"
                      rows={2}
                      value={formInput.details}
                      onChange={handleInputChange}
                      placeholder="Any specific mood board styles, lighting requests, traditional outfits details..."
                      className="w-full bg-[#141418] border border-white/5 rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-sans text-white pl-10"
                    />
                    <Notebook className="absolute left-3.5 top-3.5 h-4 w-4 text-gray-500" />
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full py-4 rounded-lg bg-gold-500 font-sans text-xs font-semibold uppercase tracking-widest text-black shadow-lg transition-all hover:bg-gold-600 mt-2 cursor-pointer"
                >
                  Authorize Reservation Request
                </motion.button>
              </form>
            </div>
          </div>
        </div>

        {/* Saved Sessions Accordion displaying local booked entries */}
        {localBookings.length > 0 && (
          <div className="mt-16 border-t border-white/5 pt-16">
            <h3 className="font-serif text-xl font-bold mb-6 text-gold-100 flex items-center gap-2">
              Your Booked Production Sessions ({localBookings.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {localBookings.map((b) => (
                <div
                  key={b.id}
                  className="bg-[#0f0f12] border border-white/5 rounded-xl p-5 relative overflow-hidden group hover:border-gold-500/20 transition-all"
                >
                  <button
                    onClick={() => deleteBooking(b.id)}
                    className="absolute top-4 right-4 text-gray-500 hover:text-red-400 transition-colors cursor-pointer"
                    title="Cancel Booking"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>

                  <span className="font-mono text-[8px] text-gold-500 uppercase tracking-widest font-bold">
                    {b.referenceCode}
                  </span>
                  <h4 className="font-serif font-semibold text-white mt-1 text-sm">{b.packageName}</h4>
                  
                  <div className="text-xs text-gray-400 space-y-1.5 mt-3 font-sans font-light">
                    <div>Date: <span className="font-mono text-white text-xs">{b.date}</span></div>
                    <div>Slot: <span className="text-white">{b.timeSlot.split(' (')[0]}</span></div>
                    <div>Venue: <span className="text-white">{b.location}</span></div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-center">
                    <span className="font-mono text-[9px] text-gray-500">Reserved on {b.createdOn}</span>
                    <span className="text-xs font-bold text-gold-500">{b.price}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
