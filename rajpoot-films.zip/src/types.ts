export type ShootingCategory = 'all' | 'wedding' | 'pre-wedding' | 'cinematic-film' | 'fashion-portrait';

export interface PortfolioItem {
  id: string;
  title: string;
  category: Exclude<ShootingCategory, 'all'>;
  url: string;
  fallbackUrl: string; // High quality unsplash fallback if the local file is not found
  aspect: 'portrait' | 'landscape' | 'wide';
  location?: string;
  year?: string;
}

export interface PricingPackage {
  id: string;
  name: string;
  tagline: string;
  price: string;
  priceValue: number;
  duration: string;
  category: Exclude<ShootingCategory, 'all'>;
  features: string[];
  recommended: boolean;
  crewDetails: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  partnerName?: string;
  quote: string;
  shootType: string;
  location: string;
  rating: number;
  date: string;
  avatarUrl: string;
}

export interface BookingFormInput {
  name: string;
  email: string;
  phone: string;
  date: string;
  timeSlot: string;
  packageId: string;
  location: string;
  details?: string;
}

export interface ContactFormInput {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}
